package com.example.practice2.service;

import com.example.practice2.dto.ProductDTO;

import java.util.List;

public interface ProductService {

    List<ProductDTO> getAll();
}
