package com.example.practice2.service;

import com.example.practice2.dto.SupplierDTO;

import java.util.List;

public interface SupplierService {

    List<SupplierDTO> getAll();
}
