package model.impl;

import model.SupplierDAO;
import model.entity.Supplier;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

public class SupplierDAOImpl implements SupplierDAO {

    private static final EntityManager entityManager = Persistence.createEntityManagerFactory("public").createEntityManager();

    @Transactional
    @Override
    public List<Supplier> suppliers() {
        return entityManager.createQuery("SELECT supplier FROM supplier").getResultList();
    }

    @Transactional
    @Override
    public boolean createSupplier(Supplier supplier) {
        System.out.println("============");
        supplier.setId((long) 3);
        System.out.println(supplier.toString());
        entityManager.getTransaction().begin();
        entityManager.persist(supplier);
        entityManager.getTransaction().commit();
        return true;
    }

    @Transactional
    @Override
    public boolean readSupplier(Supplier supplier) {
        entityManager.getTransaction().begin();
        Query query = entityManager.createQuery("SELECT supplier FROM supplier WHERE supplier.id = :id");
        query.setParameter("id", supplier.getId());
        entityManager.getTransaction().commit();
        return true;
    }

    @Transactional
    @Override
    public boolean updateSupplier(Supplier supplier) {
        entityManager.getTransaction().begin();
        Query query = entityManager.createQuery("UPDATE supplier a SET a.name = :name, a.INN = :INN, a.address = :address, a.phone = :phone "
                + "WHERE a.id = :id");
        query.setParameter("id", supplier.getId());
        query.setParameter("name", supplier.getName());
        query.setParameter("INN", supplier.getINN());
        query.setParameter("address", supplier.getAddress());
        query.setParameter("phone", supplier.getPhone());
        entityManager.getTransaction().commit();
        return true;
    }

    @Transactional
    @Override
    public boolean deleteSupplier(Supplier supplier) {
        entityManager.getTransaction().begin();
        Query query = entityManager.createQuery("DELETE FROM supplier a WHERE a.id = :id");
        query.setParameter("id", supplier.getId());
        entityManager.getTransaction().commit();
        return true;
    }

}