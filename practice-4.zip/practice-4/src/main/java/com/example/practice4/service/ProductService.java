package com.example.practice4.service;

import com.example.practice4.dto.ProductDTO;

import java.util.List;

public interface ProductService {

    List<ProductDTO> getAll();
}
