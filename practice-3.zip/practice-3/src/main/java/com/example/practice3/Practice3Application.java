package com.example.practice3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice3Application {

	public static void main(String[] args) {
		SpringApplication.run(Practice3Application.class, args);
	}

}
