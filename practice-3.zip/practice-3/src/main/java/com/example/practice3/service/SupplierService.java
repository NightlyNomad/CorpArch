package com.example.practice3.service;

import com.example.practice3.dto.SupplierDTO;
import com.example.practice3.model.Supplier;

import java.util.List;

public interface SupplierService {

    List<SupplierDTO> getAll();

    SupplierDTO get(Long id);

    void delete(Long id);

    void edit(Supplier newSupplier);

    SupplierDTO save(Supplier supplier);
}
