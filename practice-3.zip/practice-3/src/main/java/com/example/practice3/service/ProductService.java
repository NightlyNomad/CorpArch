package com.example.practice3.service;

import com.example.practice3.dto.ProductDTO;

import java.util.List;

public interface ProductService {

    List<ProductDTO> getAll();
}
